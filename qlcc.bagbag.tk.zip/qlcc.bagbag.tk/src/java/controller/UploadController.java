package controller;

import model.MyFiles;
import java.io.File;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author TVD
 */
@Controller
public class UploadController {

    private static List<MyFiles> listFiles = null;

    public UploadController() {
        this.listFiles = new ArrayList<>();
    }

    @RequestMapping(value = "list.htm", method = RequestMethod.GET)
    public String uploadList(ModelMap modelMap) {
        modelMap.put("listFiles", listFiles);
        return "upload_list";
    }

    @RequestMapping(value = "uploadFile.htm", method = RequestMethod.GET)
    public String uploadForm(ModelMap modelMap) {
        return "upload_file";
    }

    @RequestMapping(value = "uploadMultiFile.htm", method = RequestMethod.GET)
    public String uploadMulForm(ModelMap mm) {
        return "upload_multiple_file";
    }

    @RequestMapping(value = "uploadFile.htm", method = RequestMethod.POST)
    public String uploadFile(ModelMap modelMap, @RequestParam("file") MultipartFile file, HttpServletRequest request) {
        try {
            String path = request.getSession().getServletContext().getRealPath("/") + "resources/sanpham/";

            Timestamp tnow = new Timestamp(new Date().getTime());
            MyFiles f = new MyFiles();
            f.setFileId(tnow.getTime());
            f.setFileName(file.getName());
            f.setFileName(file.getOriginalFilename());
            f.setFileDate(file.getContentType());
            f.setFileSize(file.getSize());
            f.setFileDate(tnow.toString());
            listFiles.add(f);
//            FileUtils.forceMkdir(new File("D:/uploads/"));
//            File upload = new File("D:/uploads/" + file.getOriginalFilename());
//            file.transferTo(upload);
            FileUtils.forceMkdir(new File(path));
            File upload = new File(path + file.getOriginalFilename());
            file.transferTo(upload);
            f.setFilePath(path + file.getOriginalFilename());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        modelMap.put("listFiles", listFiles);
        return "home";
    }

    @RequestMapping(value = "uploadMultiFile.htm", method = RequestMethod.POST)
    public String uploadMultiFile(ModelMap modelMap, @RequestParam("files") MultipartFile[] files, HttpServletRequest request) {
        try {
            String path = request.getSession().getServletContext().getRealPath("/") + "resources/sanpham/";
            for (MultipartFile file : files) {
                Timestamp tnow = new Timestamp(new Date().getTime());
                MyFiles f = new MyFiles();
                f.setFileId(tnow.getTime());
                f.setFileName(file.getName());
                f.setFileName(file.getOriginalFilename());
                f.setFileDate(file.getContentType());
                f.setFileSize(file.getSize());
                f.setFileDate(tnow.toString());
                listFiles.add(f);
                FileUtils.forceMkdir(new File(path));
                File upload = new File(path + file.getOriginalFilename());
                file.transferTo(upload);
                f.setFilePath(path + file.getOriginalFilename());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        modelMap.put("listFiles", listFiles);
        return "upload_list";
    }

}
