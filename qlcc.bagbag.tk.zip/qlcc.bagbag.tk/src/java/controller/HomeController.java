package controller;

import java.io.File;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import static javassist.CtMethod.ConstParameter.string;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Admin;
import model.Danhmuc;
import model.HibernateUtil;
import model.MyFiles;
import model.Nhacungcap;
import model.Sanpham;
import org.apache.commons.io.FileUtils;
import static org.apache.commons.io.FileUtils.listFiles;
import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class HomeController {
    /*Start home.htm*/
    @RequestMapping(value = "home.htm", method = RequestMethod.GET)
    public String Login(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
            return "home";
        }
    }
    @RequestMapping(value = "home.htm", method = RequestMethod.POST)    
    public String Login(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
            return "home";
        }
    }
    /* End home.htm*/
    
    /*Start loadsp.htm*/
    @RequestMapping(value = "loadsp.htm", method = RequestMethod.GET)
    public String LoadSP(ModelMap mv, HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Sanpham> sanphams=sess.createQuery("from Sanpham").list();
            mv.addAttribute("sanphams",sanphams);
            return "LoadSP";
        }
    }
    @RequestMapping(value = "loadsp.htm", method = RequestMethod.POST)    
    public String LoadSP(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Sanpham> sanphams=sess.createQuery("from Sanpham").list();
            mv.addAttribute("sanphams",sanphams);
            return "LoadSP";
        }
    }
    /*End loadsp.htm*/
    
    /*Start loaddm.htm*/
    @RequestMapping(value = "loaddm.htm", method = RequestMethod.GET)
    public String LoadDM(ModelMap mv, HttpServletRequest hsr)
    {        
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Danhmuc> danhmucs=sess.createQuery("from Danhmuc").list();
            mv.addAttribute("danhmucs",danhmucs);
            return "LoadDM";
        }
    }
    @RequestMapping(value = "loaddm.htm", method = RequestMethod.POST)    
    public String LoadDM(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
       HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Danhmuc> danhmucs=sess.createQuery("from Danhmuc").list();
            mv.addAttribute("danhmucs",danhmucs);
            return "LoadDM";
        }
    }
    /*End loaddm.htm*/
    
    /*Start loadadddm.htm*/
    @RequestMapping(value = "loadadddm.htm", method = RequestMethod.GET)
    public String LoadaddDM(ModelMap mv,HttpServletRequest hsr)
    {
        
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Danhmuc> danhmucchas=sess.createQuery("from Danhmuc D  where D.danhmuc is null").list();
            mv.addAttribute("danhmucchas",danhmucchas);
            return "LoadFadddm";
        }
    }
    @RequestMapping(value = "loadadddm.htm", method = RequestMethod.POST)    
    public String LoadaddDM(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Danhmuc> danhmucchas=sess.createQuery("from Danhmuc D  where D.danhmuc is null").list();
            mv.addAttribute("danhmucchas",danhmucchas);
            return "LoadFadddm";
        }
    }
    /*End Loadadddm.htm*/  
    
     /*Start adddm.htm*/
    @RequestMapping(value = "adddm.htm", method = RequestMethod.GET)
    public String addDM(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        String iddmc= hsr.getParameter("iddmc");
        String iddm= iddmc.concat(hsr.getParameter("iddm"));
        String tendanhmuc= hsr.getParameter("tendanhmuc");
        int trangthai=0;
        int vitrixep=1;
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                if(sess.get(Danhmuc.class, iddmc)!=null)
                {
                    if(sess.get(Danhmuc.class, iddm)==null)
                    {
                    Danhmuc dmc= (Danhmuc) sess.get(Danhmuc.class, iddmc);
                    Danhmuc dm= new Danhmuc();
                    dm.setDanhmuc(dmc);
                    dm.setIddanhmuc(iddm);
                    dm.setTendanhmuc(tendanhmuc);
                    dm.setTrangthai(trangthai);
                    dm.setVitrixep(vitrixep);
                    sess.save(dm);
                    sess.getTransaction().commit();
                    List<Danhmuc> danhmucs=sess.createQuery("from Danhmuc").list();
                    mv.addAttribute("danhmucs",danhmucs);
                    return "LoadDM";
                    }
                    else
                    {
                        List<Danhmuc> danhmucchas=sess.createQuery("from Danhmuc D  where D.danhmuc is null").list();
                        mv.addAttribute("danhmucchas",danhmucchas);
                        String out="Mã danh mục đã tồn tại";
                        mv.addAttribute("messenger",out);
                        return "LoadFadddm";
                    }
                }
                else{
                    List<Danhmuc> danhmucchas=sess.createQuery("from Danhmuc D  where D.danhmuc is null").list();
                    mv.addAttribute("danhmucchas",danhmucchas);
                    String out="Vui lòng chọn tên thương hiệu";
                    mv.addAttribute("messenger",out);
                    return "LoadFadddm";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "adddm.htm", method = RequestMethod.POST)    
    public String addDM(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String iddmc= hsr.getParameter("iddmc");
        String iddm= iddmc.concat(hsr.getParameter("iddm"));
        String tendanhmuc= hsr.getParameter("tendanhmuc");
        int trangthai=0;
        int vitrixep=1;
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                if(sess.get(Danhmuc.class, iddmc)!=null)
                {
                    if(sess.get(Danhmuc.class, iddm)==null)
                    {
                    Danhmuc dmc= (Danhmuc) sess.get(Danhmuc.class, iddmc);
                    Danhmuc dm= new Danhmuc();
                    dm.setDanhmuc(dmc);
                    dm.setIddanhmuc(iddm);
                    dm.setTendanhmuc(tendanhmuc);
                    dm.setTrangthai(trangthai);
                    dm.setVitrixep(vitrixep);
                    sess.save(dm);
                    sess.getTransaction().commit();
                    List<Danhmuc> danhmucs=sess.createQuery("from Danhmuc").list();
                    mv.addAttribute("danhmucs",danhmucs);
                    return "LoadDM";
                    }
                    else
                    {
                        List<Danhmuc> danhmucchas=sess.createQuery("from Danhmuc D  where D.danhmuc is null").list();
                        mv.addAttribute("danhmucchas",danhmucchas);
                        String out="Mã danh mục đã tồn tại";
                        mv.addAttribute("messenger",out);
                        return "LoadFadddm";
                    }
                }
                else{
                    List<Danhmuc> danhmucchas=sess.createQuery("from Danhmuc D  where D.danhmuc is null").list();
                    mv.addAttribute("danhmucchas",danhmucchas);
                    String out="Vui lòng chọn tên thương hiệu";
                    mv.addAttribute("messenger",out);
                    return "LoadFadddm";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End adddm.htm*/
    
    /*Start loadchangedm.htm*/
    @RequestMapping(value = "loadchangedm.htm", method = RequestMethod.GET)
    public String LoaddieuchinhDM(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        String iddmc= hsr.getParameter("iddmc");
        String iddm= hsr.getParameter("iddm");
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            Danhmuc dmc = (Danhmuc) sess.get(Danhmuc.class, iddmc);
            mv.addAttribute("dmc",dmc);
            Danhmuc dm = (Danhmuc) sess.get(Danhmuc.class, iddm);
            mv.addAttribute("dm",dm);
            return "FdieuchinhDM";
        }
    }
    @RequestMapping(value = "loadchangedm.htm", method = RequestMethod.POST)    
    public String LoaddieuchinhDM(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        String iddmc= hsr.getParameter("iddmc");
        String iddm= hsr.getParameter("iddm");
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            Danhmuc dmc = (Danhmuc) sess.get(Danhmuc.class, iddmc);
            mv.addAttribute("dmc",dmc);
            Danhmuc dm = (Danhmuc) sess.get(Danhmuc.class, iddm);
            mv.addAttribute("dm",dm);
            return "FdieuchinhDM";
        }
    }
    /*End Loadchangedm.htm*/
    
    /*Start loadchangedm.htm*/
    @RequestMapping(value = "loadchangedmc.htm", method = RequestMethod.GET)
    public String LoaddieuchinhTH(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            String iddm= hsr.getParameter("iddm");
            Danhmuc dm = (Danhmuc) sess.get(Danhmuc.class, iddm);
            mv.addAttribute("dm",dm);
            return "FdieuchinhTH";
        }
    }
    @RequestMapping(value = "loadchangedmc.htm", method = RequestMethod.POST)    
    public String LoaddieuchinhTH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            String iddm= hsr.getParameter("iddm");
            Danhmuc dm = (Danhmuc) sess.get(Danhmuc.class, iddm);
            mv.addAttribute("dm",dm);
            return "FdieuchinhTH";
        }
    }
    /*End Loadadddm.htm*/  
    
    /*Start changedm.htm*/
    @RequestMapping(value = "changedm.htm", method = RequestMethod.GET)
    public String dieuchinhDM(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        String iddm= hsr.getParameter("iddm");
        String tendanhmuc= hsr.getParameter("tendanhmuc");
        int trangthai= Integer.parseInt(hsr.getParameter("trangthai"));
        int vitrixep=1; 
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Danhmuc dm= (Danhmuc) sess.get(Danhmuc.class, iddm);
                dm.setTendanhmuc(tendanhmuc);
                dm.setTrangthai(trangthai);
                sess.save(dm);
                sess.getTransaction().commit();
                List<Danhmuc> danhmucs=sess.createQuery("from Danhmuc").list();
                mv.addAttribute("danhmucs",danhmucs);
                return "LoadDM";
                
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "changedm.htm", method = RequestMethod.POST)    
    public String dieuchinhDM(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String iddm= hsr.getParameter("iddm");
        String tendanhmuc= hsr.getParameter("tendanhmuc");
        int trangthai= Integer.parseInt(hsr.getParameter("trangthai"));
        int vitrixep=1; 
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Danhmuc dm= (Danhmuc) sess.get(Danhmuc.class, iddm);
                dm.setTendanhmuc(tendanhmuc);
                dm.setTrangthai(trangthai);
                sess.save(dm);
                sess.getTransaction().commit();
                List<Danhmuc> danhmucs=sess.createQuery("from Danhmuc").list();
                mv.addAttribute("danhmucs",danhmucs);
                return "LoadDM";
                
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End changedm.htm*/
    
    /*Start changedmc.htm*/
    @RequestMapping(value = "changedmc.htm", method = RequestMethod.GET)
    public String dieuchinhTH(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        String iddm= hsr.getParameter("iddm");
        String tendanhmuc= hsr.getParameter("tendanhmuc");
        int trangthai= Integer.parseInt(hsr.getParameter("trangthai"));
        int vitrixep=1; 
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Danhmuc dm= (Danhmuc) sess.get(Danhmuc.class, iddm);
                dm.setTendanhmuc(tendanhmuc);
                dm.setTrangthai(trangthai);
                sess.save(dm);
                sess.getTransaction().commit();
                List<Danhmuc> danhmucs=sess.createQuery("from Danhmuc").list();
                mv.addAttribute("danhmucs",danhmucs);
                return "LoadDM";
                
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "changedmc.htm", method = RequestMethod.POST)    
    public String dieuchinhTH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String iddm= hsr.getParameter("iddm");
        String tendanhmuc= hsr.getParameter("tendanhmuc");
        int trangthai= Integer.parseInt(hsr.getParameter("trangthai"));
        int vitrixep=1; 
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Danhmuc dm= (Danhmuc) sess.get(Danhmuc.class, iddm);
                dm.setTendanhmuc(tendanhmuc);
                dm.setTrangthai(trangthai);
                sess.save(dm);
                sess.getTransaction().commit();
                List<Danhmuc> danhmucs=sess.createQuery("from Danhmuc").list();
                mv.addAttribute("danhmucs",danhmucs);
                return "LoadDM";
                
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End adddm.htm*/
    
    /*Start loadadddmc.htm*/
    @RequestMapping(value = "loadadddmc.htm", method = RequestMethod.GET)
    public String LoadaddTH(ModelMap mv,HttpServletRequest hsr)
    {
        
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "LoadFaddTH";
        }
    }
    @RequestMapping(value = "loadadddmc.htm", method = RequestMethod.POST)    
    public String LoadaddTH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "LoadFaddTH";
        }
    }
    /*End Loadadddmc.htm*/  
    
     /*Start adddmc.htm*/
    @RequestMapping(value = "adddmc.htm", method = RequestMethod.GET)
    public String addDMC(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        String iddmc="null";
        String iddm= hsr.getParameter("iddm");
        String tendanhmuc= hsr.getParameter("tendanhmuc");
        int trangthai=0;
        int vitrixep=0;
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                if(sess.get(Danhmuc.class, iddm)==null)
                {
                Danhmuc dmc= (Danhmuc) sess.get(Danhmuc.class, iddmc);
                Danhmuc dm= new Danhmuc();
                dm.setDanhmuc(dmc);
                dm.setIddanhmuc(iddm);
                dm.setTendanhmuc(tendanhmuc);
                dm.setTrangthai(trangthai);
                dm.setVitrixep(vitrixep);
                sess.save(dm);
                sess.getTransaction().commit();
                List<Danhmuc> danhmucs=sess.createQuery("from Danhmuc").list();
                mv.addAttribute("danhmucs",danhmucs);
                return "LoadDM";
                }
                else
                {
                    String out="Mã danh mục đã tồn tại";
                    mv.addAttribute("messenger",out);
                    return "LoadFaddTH";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "adddmc.htm", method = RequestMethod.POST)    
    public String addDMC(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String iddmc="null";
        String iddm= hsr.getParameter("iddm");
        String tendanhmuc= hsr.getParameter("tendanhmuc");
        int trangthai=0;
        int vitrixep=0;
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                if(sess.get(Danhmuc.class, iddm)==null)
                {
                Danhmuc dmc= (Danhmuc) sess.get(Danhmuc.class, iddmc);
                Danhmuc dm= new Danhmuc();
                dm.setDanhmuc(dmc);
                dm.setIddanhmuc(iddm);
                dm.setTendanhmuc(tendanhmuc);
                dm.setTrangthai(trangthai);
                dm.setVitrixep(vitrixep);
                sess.save(dm);
                sess.getTransaction().commit();
                List<Danhmuc> danhmucs=sess.createQuery("from Danhmuc").list();
                mv.addAttribute("danhmucs",danhmucs);
                return "LoadDM";
                }
                else
                {
                    String out="Mã danh mục đã tồn tại";
                    mv.addAttribute("messenger",out);
                    return "LoadFaddTH";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End adddmc.htm*/ 
    
    /*Start loadncc.htm*/
    @RequestMapping(value = "loadncc.htm", method = RequestMethod.GET)
    public String LoadNCC(ModelMap mv, HttpServletRequest hsr)
    {        
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Nhacungcap> nccs=sess.createQuery("from Nhacungcap").list();
            mv.addAttribute("nccs",nccs);
            return "LoadNCC";
        }
    }
    @RequestMapping(value = "loadncc.htm", method = RequestMethod.POST)    
    public String LoadNCC(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
       HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Nhacungcap> nccs=sess.createQuery("from Nhacungcap").list();
            mv.addAttribute("nccs",nccs);
            return "LoadNCC";
        }
    }
    /*End loadncc.htm*/
    
    /*Start loadncc.htm*/
    @RequestMapping(value = "loadaddncc.htm", method = RequestMethod.GET)
    public String LoadaddNCC(ModelMap mv, HttpServletRequest hsr)
    {        
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "LoadFaddNCC";
        }
    }
    @RequestMapping(value = "loadaddncc.htm", method = RequestMethod.POST)    
    public String LoadaddNCC(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
       HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "LoadFaddNCC";
        }
    }
    /*End loadaddncc.htm*/
    
     /*Start adddmc.htm*/
    @RequestMapping(value = "addncc.htm", method = RequestMethod.GET)
    public String addNCC(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        String idncc= hsr.getParameter("id");       
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                if(sess.get(Nhacungcap.class, idncc)==null)
                {
                String tennhacungcap= hsr.getParameter("tennhacungcap");
                String daidien= hsr.getParameter("daidien");
                String sdt= hsr.getParameter("sdt");
                String diachi= hsr.getParameter("diachi");
                int trangthai=1;
                Nhacungcap nccn = new Nhacungcap();
                nccn.setIdncc(idncc);
                nccn.setTennhacungcap(tennhacungcap);
                nccn.setDaidien(daidien);
                nccn.setSdt(sdt);
                nccn.setDiachi(diachi);
                nccn.setTrangthai(trangthai);
                sess.save(nccn);
                sess.getTransaction().commit();
                List<Nhacungcap> nccs=sess.createQuery("from Nhacungcap").list();
                mv.addAttribute("nccs",nccs);
                return "LoadNCC";
                }
                else
                {
                    String out="Mã nhà cung cấp đã tồn tại";
                    mv.addAttribute("messenger",out);
                    return "LoadFaddNCC";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "addncc.htm", method = RequestMethod.POST)    
    public String addNCC(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String idncc= hsr.getParameter("id");       
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                if(sess.get(Nhacungcap.class, idncc)==null)
                {
                String tennhacungcap= hsr.getParameter("tennhacungcap");
                String daidien= hsr.getParameter("daidien");
                String sdt= hsr.getParameter("sdt");
                String diachi= hsr.getParameter("diachi");
                int trangthai=1;
                Nhacungcap nccn = new Nhacungcap();
                nccn.setIdncc(idncc);
                nccn.setTennhacungcap(tennhacungcap);
                nccn.setDaidien(daidien);
                nccn.setSdt(sdt);
                nccn.setDiachi(diachi);
                nccn.setTrangthai(trangthai);
                sess.save(nccn);
                sess.getTransaction().commit();
                List<Nhacungcap> nccs=sess.createQuery("from Nhacungcap").list();
                mv.addAttribute("nccs",nccs);
                return "LoadNCC";
                }
                else
                {
                    String out="Mã nhà cung cấp đã tồn tại";
                    mv.addAttribute("messenger",out);
                    return "LoadFaddNCC";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End addncc.htm*/ 
    
    /*Start loadchangencc.htm*/
    @RequestMapping(value = "loadchangencc.htm", method = RequestMethod.GET)
    public String loadchangeNCC(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            String idncc = hsr.getParameter("idncc");
            Nhacungcap ncc= (Nhacungcap) sess.get(Nhacungcap.class, idncc);
            mv.addAttribute("ncc", ncc);
            return "FdieuchinhNCC";
        }
    }
    @RequestMapping(value = "loadchangencc.htm", method = RequestMethod.POST)    
    public String loadchangeNCC(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            String idncc = hsr.getParameter("idncc");
            Nhacungcap ncc= (Nhacungcap) sess.get(Nhacungcap.class, idncc);
            mv.addAttribute("ncc", ncc);
            return "FdieuchinhNCC";
        }
    }
    /*End loadchangencc.htm*/ 
    
    /*Start adddmc.htm*/
    @RequestMapping(value = "changencc.htm", method = RequestMethod.GET)
    public String changeNCC(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        String idncc= hsr.getParameter("id");       
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                String tennhacungcap= hsr.getParameter("tennhacungcap");
                String daidien= hsr.getParameter("daidien");
                String sdt= hsr.getParameter("sdt");
                String diachi= hsr.getParameter("diachi");
                int trangthai= Integer.parseUnsignedInt(hsr.getParameter("trangthai"));
                Nhacungcap nccn = (Nhacungcap) sess.get(Nhacungcap.class, idncc);
                nccn.setTennhacungcap(tennhacungcap);
                nccn.setDaidien(daidien);
                nccn.setSdt(sdt);
                nccn.setDiachi(diachi);
                nccn.setTrangthai(trangthai);
                sess.save(nccn);
                sess.getTransaction().commit();
                List<Nhacungcap> nccs=sess.createQuery("from Nhacungcap").list();
                mv.addAttribute("nccs",nccs);
                return "LoadNCC";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "changencc.htm", method = RequestMethod.POST)    
    public String changeNCC(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String idncc= hsr.getParameter("id");       
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                String tennhacungcap= hsr.getParameter("tennhacungcap");
                String daidien= hsr.getParameter("daidien");
                String sdt= hsr.getParameter("sdt");
                String diachi= hsr.getParameter("diachi");
                int trangthai= Integer.parseUnsignedInt(hsr.getParameter("trangthai"));
                Nhacungcap nccn = (Nhacungcap) sess.get(Nhacungcap.class, idncc);
                nccn.setTennhacungcap(tennhacungcap);
                nccn.setDaidien(daidien);
                nccn.setSdt(sdt);
                nccn.setDiachi(diachi);
                nccn.setTrangthai(trangthai);
                sess.save(nccn);
                sess.getTransaction().commit();
                List<Nhacungcap> nccs=sess.createQuery("from Nhacungcap").list();
                mv.addAttribute("nccs",nccs);
                return "LoadNCC";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End changencc.htm*/ 
    
    /*Start loadnv.htm*/
    @RequestMapping(value = "loadnv.htm", method = RequestMethod.GET)
    public String LoadNV(ModelMap mv, HttpServletRequest hsr)
    {        
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Admin> nvkvs=sess.createQuery("from Admin A where A.capdo=2 or A.capdo=3").list();
            mv.addAttribute("nvs",nvkvs);
//            List<Admin> nvtvs=sess.createQuery("from Admin A where A.capdo=3").list();
//            mv.addAttribute("nvtvs",nvtvs);
            return "LoadNV";
        }
    }
    @RequestMapping(value = "loadnv.htm", method = RequestMethod.POST)    
    public String LoadNV(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
       HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Admin> nvkvs=sess.createQuery("from Admin A where A.capdo=2 A.capdo=3").list();
            mv.addAttribute("nvs",nvkvs);
//            List<Admin> nvtvs=sess.createQuery("from Admin A where A.capdo=3").list();
//            mv.addAttribute("nvtvs",nvtvs);
            return "LoadNV";
        }
    }
    /*End loadnv.htm*/
    
    /*Start loadaddnv.htm*/
    @RequestMapping(value = "loadaddnv.htm", method = RequestMethod.GET)
    public String LoadaddNV(ModelMap mv,HttpServletRequest hsr)
    {
        
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "LoadFaddNV";
        }
    }
    @RequestMapping(value = "loadaddnv.htm", method = RequestMethod.POST)    
    public String LoadaddNV(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "LoadFaddNV";
        }
    }
    /*End Loadaddnv.htm*/  
    
    /*Start addnv.htm*/
    @RequestMapping(value = "addnv.htm", method = RequestMethod.GET)
    public String addNV(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        String nv = hsr.getParameter("capdo");
        String id= nv.concat(hsr.getParameter("id")) ;
        String pass=MD5Library.md5(id);
        String hoten= hsr.getParameter("hoten");
        String sdt= hsr.getParameter("sdt");
        String email = hsr.getParameter("email");
        int trangthai=0;
        int capdo=Integer.parseInt(nv);
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                if(sess.get(Admin.class,id)==null)
                {
                    Admin adn= new Admin();
                    adn.setIdadmin(id);
                    adn.setPass(pass);
                    adn.setHoten(hoten);
                    adn.setSdt(sdt);
                    adn.setEmail(email);
                    adn.setTrangthai(trangthai);
                    adn.setCapdo(capdo);
                    adn.setThoigiantao(Date.from(Instant.now()));
                    sess.save(adn);
                    sess.getTransaction().commit();
                    List<Admin> nvkvs=sess.createQuery("from Admin A where A.capdo=2 or A.capdo=3").list();
                    mv.addAttribute("nvs",nvkvs);
                    return "LoadNV";
                }
                else{
                    String out="Mã nhân viên: "+ id +" đã tồn tại vui lòng kiểm tra lại";
                    mv.addAttribute("messenger",out);
                    return "LoadFaddNV";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "addnv.htm", method = RequestMethod.POST)    
    public String addNV(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String nv = hsr.getParameter("capdo");
        String id= nv.concat(hsr.getParameter("id")) ;
        String pass=MD5Library.md5(id);
        String hoten= hsr.getParameter("hoten");
        String sdt= hsr.getParameter("sdt");
        String email = hsr.getParameter("email");
        int trangthai=0;
        int capdo=Integer.parseInt(nv);
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                if(sess.get(Admin.class,id)==null)
                {
                    Admin adn= new Admin();
                    adn.setIdadmin(id);
                    adn.setPass(pass);
                    adn.setHoten(hoten);
                    adn.setSdt(sdt);
                    adn.setEmail(email);
                    adn.setTrangthai(trangthai);
                    adn.setCapdo(capdo);
                    adn.setThoigiantao(Date.from(Instant.now()));
                    sess.save(adn);
                    sess.getTransaction().commit();
                    List<Admin> nvkvs=sess.createQuery("from Admin A where A.capdo=2 or A.capdo=3").list();
                    mv.addAttribute("nvs",nvkvs);
                    return "LoadNV";
                }
                else{
                    String out="Mã nhân viên: "+ id +" đã tồn tại vui lòng kiểm tra lại";
                    mv.addAttribute("messenger",out);
                    return "LoadFaddNV";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End addnv.htm*/ 
    
    /*Start loadchangenv.htm*/
    @RequestMapping(value = "loadchangenv.htm", method = RequestMethod.GET)
    public String loadchangeNV(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        String idnv = hsr.getParameter("idnv");
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            Admin nv= (Admin) sess.get(Admin.class, idnv);
            mv.addAttribute("nv", nv);
            return "FdieuchinhNV";
        }
    }
    @RequestMapping(value = "loadchangenv.htm", method = RequestMethod.POST)    
    public String loadchangeNV(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        String idnv = hsr.getParameter("idnv");
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            Admin nv= (Admin) sess.get(Admin.class, idnv);
            mv.addAttribute("nv", nv);
            return "FdieuchinhNV";
        }
    }
    /*End loadchangenv.htm*/ 
    
    /*Start changenv.htm*/
    @RequestMapping(value = "changenv.htm", method = RequestMethod.GET)
    public String changeNV(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        int capdo=Integer.parseInt(hsr.getParameter("capdo"));
        String id= hsr.getParameter("id") ;
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin adn= (Admin) sess.get(Admin.class,id);
                adn.setCapdo(capdo);
                sess.save(adn);
                sess.getTransaction().commit();
                List<Admin> nvkvs=sess.createQuery("from Admin A where A.capdo=2 or A.capdo=3").list();
                mv.addAttribute("nvs",nvkvs);
                return "LoadNV";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "changenv.htm", method = RequestMethod.POST)    
    public String changeNV(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        int capdo=Integer.parseInt(hsr.getParameter("capdo"));
        String id= hsr.getParameter("id") ;
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin adn= (Admin) sess.get(Admin.class,id);
                adn.setCapdo(capdo);
                sess.save(adn);
                sess.getTransaction().commit();
                List<Admin> nvkvs=sess.createQuery("from Admin A where A.capdo=2 or A.capdo=3").list();
                mv.addAttribute("nvs",nvkvs);
                return "LoadNV";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End changenv.htm*/ 
    
    /*Start Locknv.htm*/
    @RequestMapping(value = "locknv.htm", method = RequestMethod.GET)
    public String LockNV(ModelMap mv,HttpServletRequest hsr)
    {
        String idk= hsr.getParameter("idnv");
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            Admin khk=(Admin)sess.get(Admin.class,idk);
            khk.setTrangthai(2);
            sess.save(khk);
            sess.getTransaction().commit();
            
            Admin khkt=(Admin)sess.get(Admin.class,idk);
            if(khkt.getTrangthai()==2)
            {
                List<Admin> nvkvs=sess.createQuery("from Admin A where A.capdo=2 or A.capdo=3").list();
                mv.addAttribute("nvs",nvkvs);
                return "LoadNV";
            }
            else
            {
                String out="Khóa tài khoản thất bại";
                mv.addAttribute("mess",out);
                return "LoadNV";
            }
        }
    }
    @RequestMapping(value = "locknv.htm", method = RequestMethod.POST)    
    public String LockNV(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        String idk= hsr.getParameter("idnv");
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            Admin khk=(Admin)sess.get(Admin.class,idk);
            khk.setTrangthai(2);
            sess.save(khk);
            sess.getTransaction().commit();
            
            Admin khkt=(Admin)sess.get(Admin.class,idk);
            if(khkt.getTrangthai()==2)
            {
                List<Admin> nvkvs=sess.createQuery("from Admin A where A.capdo=2 or A.capdo=3").list();
                mv.addAttribute("nvs",nvkvs);
                return "LoadNV";
            }
            else
            {
                String out="Khóa tài khoản thất bại";
                mv.addAttribute("mess",out);
                return "LoadNV";
            }
        }
    }
    /*End Locknv.htm*/
    
    /*Start loadchangesp.htm*/
    @RequestMapping(value = "loadchangesp.htm", method = RequestMethod.GET)
    public String LoadchangeSP(ModelMap mv, HttpServletRequest hsr)
    {        
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            String idsp = hsr.getParameter("idsp");
            Sanpham sp = (Sanpham) sess.get(Sanpham.class,idsp);
            mv.addAttribute("sp",sp);
            return "FdieuchinhSP";
        }
    }
    @RequestMapping(value = "loadchangesp.htm", method = RequestMethod.POST)    
    public String LoadchangeSP(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            String idsp = hsr.getParameter("idsp");
            Sanpham sp = (Sanpham) sess.get(Sanpham.class,idsp);
            mv.addAttribute("sp",sp);
            return "FdieuchinhSP";
        }
    }
    /*End Loadchangesp.htm*/
    
    /*Start changesp.htm*/
    @RequestMapping(value = "changesp.htm", method = RequestMethod.GET)
    public String changeSP(ModelMap mv, HttpServletRequest hsr)
    {        
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            String idsp = hsr.getParameter("idsp");
            String tensp = hsr.getParameter("tensp");
            float gia = Float.parseFloat(hsr.getParameter("giasp"));
            int tt = Integer.parseInt(hsr.getParameter("trangthai"));
            Sanpham sp = (Sanpham) sess.get(Sanpham.class,idsp);
            if(sp!=null)
            {
                sp.setTensanpham(tensp);
                sp.setTrangthai(tt);
                sp.setDongiaban(gia);
                sess.getTransaction().commit();
                List<Sanpham> sanphams=sess.createQuery("from Sanpham").list();
                mv.addAttribute("sanphams",sanphams);
                String out="Điều chỉnh thành công";
                mv.addAttribute("mess", out);
                return "LoadSP";
            }
            else
            {
            String out="Điều chỉnh thất bại";
            mv.addAttribute("mess", out);
            mv.addAttribute("sp",sp);
            return "FdieuchinhSP";
            }
        }
    }
    @RequestMapping(value = "changesp.htm", method = RequestMethod.POST)    
    public String changeSP(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            String idsp = hsr.getParameter("idsp");
            String tensp = hsr.getParameter("tensp");
            float gia = Float.parseFloat(hsr.getParameter("giasp"));
            int tt = Integer.parseInt(hsr.getParameter("trangthai"));
            Sanpham sp = (Sanpham) sess.get(Sanpham.class,idsp);
            if(sp!=null)
            {
                sp.setTensanpham(tensp);
                sp.setTrangthai(tt);
                sp.setDongiaban(gia);
                sess.getTransaction().commit();
                List<Sanpham> sanphams=sess.createQuery("from Sanpham").list();
                mv.addAttribute("sanphams",sanphams);
                String out="Điều chỉnh thành công";
                mv.addAttribute("mess", out);
                return "LoadSP";
            }
            else
            {
            String out="Điều chỉnh thất bại";
            mv.addAttribute("mess", out);
            mv.addAttribute("sp",sp);
            return "FdieuchinhSP";
            }
        }
    }
    /*End changesp.htm*/
    
    /*Các chức năng chưa thực hiện*/
    
    /*Start htdoanhthu.htm chưa thực hiện*/
     @RequestMapping(value = "htdoanhthu.htm", method = RequestMethod.GET)
    public String Doanhthu(ModelMap mv, HttpServletRequest hsr)
    {        
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "Doanhthu";
        }
    }
    @RequestMapping(value = "htdoanhthu.htm", method = RequestMethod.POST)    
    public String Doanhthu(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "Doanhthu";
        }
    }
    /*End htdoanhthu.htm*/
    
    /*Start htgiaban.htm chưa thực hiện*/
    @RequestMapping(value = "htgiaban.htm", method = RequestMethod.GET)
    public String Giaban(ModelMap mv, HttpServletRequest hsr)
    {        
         HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "Giaban";
        }
    }
    @RequestMapping(value = "htgiaban.htm", method = RequestMethod.POST)    
    public String Giaban(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "Giaban";
        }
    }
    /*End htgiaban.htm*/
    
    /*Start loaduploadFile.htm chưa thực hiện*/
    @RequestMapping(value = "loaduploadFile.htm", method = RequestMethod.GET)
    public String UpF(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "upload_file";
        }
    }
    @RequestMapping(value = "loaduploadFile.htm", method = RequestMethod.POST)    
    public String UpF(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "upload_file";
        }
    }
    /*End loaduploadFile.htm */
    
    /*Start loadaddsp.htm chưa thực hiện*/
    @RequestMapping(value = "loadaddsp.htm", method = RequestMethod.GET)
    public String LoadaddSP(ModelMap mv, HttpServletRequest hsr)
    {        
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "XD";
        }
    }
    @RequestMapping(value = "loadaddsp.htm", method = RequestMethod.POST)    
    public String LoadaddSP(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(ss==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            return "XD";
        }
    }
    /*End loadaddsp.htm*/
    
    /*BÙI LÊ NHỰT TÀI - D15TH01 - DH51500015 - STU*/

}
