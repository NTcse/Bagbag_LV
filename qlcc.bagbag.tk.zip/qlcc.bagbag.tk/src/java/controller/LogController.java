
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import controller.MD5Library;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Admin;
import model.HibernateUtil;
import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller

public class LogController {
    @RequestMapping(value = "login.htm", method = RequestMethod.GET)
    public String Login()
    {
        return "index";
    }
    @RequestMapping(value = "login.htm", method = RequestMethod.POST)    
    public String login(ModelMap mv, HttpServletRequest hsr)
    {     
        String out ="Đăng nhập Thất Bại";
        String id= hsr.getParameter("iduser");
        String pass=hsr.getParameter("pass");       
        try{
            if(id==null || pass==null)
            {
                out="Hãy nhập ID và password";
                mv.addAttribute("messenger",out);
                return "index";
            }
            else
            {
                Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                if(kh!=null)
                {                      
                    int tt=kh.getTrangthai();
                    if(tt==1)
                    {
                        if(kh.getPass().equals(MD5Library.md5(pass)) && kh.getCapdo()==1)
                        {
                            mv.addAttribute("id",kh);
                            out="Đăng nhập Thành công";
                            mv.addAttribute("messenger",out);
                            HttpSession session = hsr.getSession();
                            String sessadmin = kh.getIdadmin();
                            session.setAttribute("sessadmin", sessadmin);
                            // sess.getTransaction().commit();
                            //sess.close();
                            return "home";
                        }
                        else 
                        {
                            out="Sai Mật Khẩu hoặc Bạn không có quyền truy cập";
                            mv.addAttribute("messenger",out);
                            sess.getTransaction().commit();
                            sess.close();
                            return "index";
                        }
                    }
                    else if(tt==0)
                    {
                        mv.addAttribute("id",kh);
                            out="Tài khoản được kích hoạt vui lòng đổi mật khẩu";
                            mv.addAttribute("messenger",out);
                            HttpSession session = hsr.getSession();
                            String sessadmin = kh.getIdadmin();
                            session.setAttribute("sessadmin", sessadmin);
                            // sess.getTransaction().commit();
                            //sess.close();
                            return "active";
                    }
                    else if(tt==2)
                    {
                        out="Tài khoản đã bị khóa";
                            mv.addAttribute("messenger",out);
                            sess.getTransaction().commit();
                            sess.close();
                            return "index";
                    }
                    else
                    {
                        out="Tài khoản tạm khóa hoặc chưa kích hoạt";
                        mv.addAttribute("messenger",out);
                        sess.getTransaction().commit();
                        sess.close();
                        return "index";
                    }
                }
                else
                {
                    out="Tài khoản không tồn tại";
                    mv.addAttribute("messenger",out);
                    sess.getTransaction().commit();
                    sess.close();
                    return "index";
                }
             }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }         
    }
    @RequestMapping(value = "logout.htm", method = RequestMethod.GET)
    public String logout (ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
            throws ServletException, IOException
    { 
        HttpSession session = hsr.getSession();
        session.removeAttribute("sessadmin");
        return "index";
    }
    @RequestMapping(value = "active.htm", method = RequestMethod.GET)    
    public String Reset_pass(ModelMap mv, HttpServletRequest hsr)
    {   
        HttpSession session = hsr.getSession();
        
        String id= (String) session.getAttribute("sessadmin");
        String out ="Đổi pass Thất Bại";
        String old_p= hsr.getParameter("pass_old");
        String new_p=hsr.getParameter("pass_new1");       
        try{
            if(old_p==null || new_p==null)
            {
                out="Hãy nhập password của bạn và password mới";
                mv.addAttribute("mess",out);
                return "active";
            }
            else
            {
                Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                if(kh!=null)
                {
                    kh.setPass(MD5Library.md5(new_p));
                    kh.setTrangthai(1);
                    sess.save(kh);
                    
                    Admin khkt=(Admin)sess.get(Admin.class,id);
                    if(khkt.getPass().equals(MD5Library.md5(new_p)))
                    {
                        session.removeAttribute("sessadmin");
                        out="Đổi mật khẩu thành công. Vui lòng đăng nhập lại";
                        mv.addAttribute("messenger",out);
                        sess.getTransaction().commit();
                        sess.close();
                        return "index";
                    }
                    else
                    {
                        out="Thay đổi mật khẩu thất bại";
                        mv.addAttribute("mess",out);
                        return "active";
                    }
                }
                else
                {
                    out="Thay đổi mật khẩu thất bại";
                    mv.addAttribute("mess",out);
                    return "active";
                }
             }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }     
    }
    @RequestMapping(value = "active.htm", method = RequestMethod.POST)    
    public String Reset_pass(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {   
        HttpSession session = hsr.getSession();
        String id= (String) session.getAttribute("sessadmin");
        String out ="Đổi pass Thất Bại";
        String old_p= hsr.getParameter("pass_old");
        String new_p=hsr.getParameter("pass_new1");       
        try{
            if(old_p==null || new_p==null || old_p==new_p)
            {
                if(old_p==new_p)
                {out="Hãy nhập password mới khác password hiện tại";}
                else
                {out="Hãy nhập password của bạn và password mới";}
                mv.addAttribute("mess",out);
                return "active";
            }
            else
            {
                Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                if(kh!=null)
                {
                    kh.setPass(MD5Library.md5(new_p));
                    kh.setTrangthai(1);
                    sess.save(kh);
                    Admin khkt=(Admin)sess.get(Admin.class,id);
                    if(khkt.getPass().equals(MD5Library.md5(new_p)))
                    {
                        session.removeAttribute("sessadmin");
                        out="Đổi mật khẩu thành công. Vui lòng đăng nhập lại";
                        mv.addAttribute("messenger",out);
                        sess.getTransaction().commit();
                        sess.close();
                        return "index";
                    }
                    else
                    {
                        out="Thay đổi mật khẩu thất bại";
                        mv.addAttribute("mess",out);
                        return "active";
                    }
                }
                else
                {
                    out="Thay đổi mật khẩu thất bại";
                    mv.addAttribute("mess",out);
                    return "active";
                }
             }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }     
    }
}
