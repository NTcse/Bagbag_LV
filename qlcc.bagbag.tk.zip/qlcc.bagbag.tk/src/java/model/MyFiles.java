package model;

/**
 *
 * @author TVD
 */
public class MyFiles {

    private long fileId;
    private String fileName;
    private String filePath;
    private String fileOriginalFilename;
    private String fileContentType;
    private long fileSize;
    private String fileDate;

    public long getFileId() {
        return fileId;
    }

    public void setFileId(long fileId) {
        this.fileId = fileId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getFileOriginalFilename() {
        return fileOriginalFilename;
    }

    public void setFileOriginalFilename(String fileOriginalFilename) {
        this.fileOriginalFilename = fileOriginalFilename;
    }

    public String getFileContentType() {
        return fileContentType;
    }

    public void setFileContentType(String fileContentType) {
        this.fileContentType = fileContentType;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public String getFileDate() {
        return fileDate;
    }

    public void setFileDate(String fileDate) {
        this.fileDate = fileDate;
    }

}
