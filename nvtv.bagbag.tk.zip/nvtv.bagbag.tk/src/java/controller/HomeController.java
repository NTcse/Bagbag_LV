
package controller;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Admin;
import model.Chitiethoadon;
import model.HibernateUtil;
import model.Hoadon;
import model.Sanpham;
import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
    
    /*Start home.htm*/
    @RequestMapping(value = "home.htm", method = RequestMethod.GET)
    public String Login(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
            return "home";
        }
    }
    @RequestMapping(value = "home.htm", method = RequestMethod.POST)    
    public String Login(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
            return "home";
        }
    }
    /* End home.htm*/
    
    /*Start loaddh.htm*/
    @RequestMapping(value = "loaddh.htm", method = RequestMethod.GET)
    public String LoadDH(ModelMap mv, HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Hoadon> cxls=sess.createQuery("from Hoadon H where H.trangthai=1").list();
            mv.addAttribute("cxls",cxls);
            List<Hoadon> dcgs=sess.createQuery("from Hoadon H where H.trangthai=2 or H.trangthai=3 or H.trangthai=4 ").list();
            mv.addAttribute("dcgs",dcgs);
            List<Hoadon> hts=sess.createQuery("from Hoadon H where H.trangthai=5").list();
            mv.addAttribute("hts",hts);
            List<Hoadon> huys=sess.createQuery("from Hoadon H where H.trangthai=0").list();
            mv.addAttribute("huys",huys);
            return "LoadDH";
        }
    }
    @RequestMapping(value = "loaddh.htm", method = RequestMethod.POST)    
    public String LoadDH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Hoadon> cxls=sess.createQuery("from Hoadon H where H.trangthai=1").list();
            mv.addAttribute("cxls",cxls);
            List<Hoadon> dcgs=sess.createQuery("from Hoadon H where H.trangthai=2 or H.trangthai=3 or H.trangthai=4 ").list();
            mv.addAttribute("dcgs",dcgs);
            List<Hoadon> hts=sess.createQuery("from Hoadon H where H.trangthai=5").list();
            mv.addAttribute("hts",hts);
            List<Hoadon> huys=sess.createQuery("from Hoadon H where H.trangthai=0").list();
            mv.addAttribute("huys",huys);
            return "LoadDH";
        }
    }
    /*End loaddh.htm*/
    
    /*Start loadctdh.htm*/
    @RequestMapping(value = "loadctdh.htm", method = RequestMethod.GET)
    public String LoadCTDH(ModelMap mv, HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        String iddh= hsr.getParameter("iddh");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            Hoadon dh = (Hoadon) sess.get(Hoadon.class, iddh);
            mv.addAttribute("dh",dh);
            List<Chitiethoadon> chitiethoadons = sess.createQuery("from Chitiethoadon where mahoadon like '%"+iddh+"%'").list();
            mv.addAttribute("ctdhs",chitiethoadons);
            List<Sanpham> sps = sess.createQuery("from Sanpham").list();
            mv.addAttribute("sps", sps);
            return "chitietdonhang";
        }
    }
    @RequestMapping(value = "loadctdh.htm", method = RequestMethod.POST)    
    public String LoadCTDH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        String iddh= hsr.getParameter("iddh");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
           Hoadon dh = (Hoadon) sess.get(Hoadon.class, iddh);
            mv.addAttribute("dh",dh);            
            return "chitietdonhang";
        }
    }
    /*End loadctdh.htm*/
    
    /*Start xoactdh.htm*/
    @RequestMapping(value = "xoactdh.htm", method = RequestMethod.GET)
    public String XoaCTDH(ModelMap mv, HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            String iddh= hsr.getParameter("iddh");
            int idct= Integer.parseInt(hsr.getParameter("idct")) ;
            Chitiethoadon ctdhx = (Chitiethoadon) sess.get(Chitiethoadon.class, idct);
            Float tru = ctdhx.getSoluong() * ctdhx.getDongiaban();
            sess.delete(ctdhx); 
            Hoadon dh = (Hoadon) sess.get(Hoadon.class, iddh);
            dh.setTrigiahoadon(dh.getTrigiahoadon()-tru);
            sess.getTransaction().commit();
            mv.addAttribute("dh",dh);
            List<Chitiethoadon> chitiethoadons = sess.createQuery("from Chitiethoadon where mahoadon like '%"+iddh+"%'").list();
            mv.addAttribute("ctdhs",chitiethoadons);
            List<Sanpham> sps = sess.createQuery("from Sanpham").list();
            mv.addAttribute("sps", sps);
            return "chitietdonhang";
        }
    }
    @RequestMapping(value = "xoactdh.htm", method = RequestMethod.POST)    
    public String xoaCTDH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            String iddh= hsr.getParameter("iddh");
            int idct= Integer.parseInt(hsr.getParameter("idct")) ;
            Chitiethoadon ctdhx = (Chitiethoadon) sess.get(Chitiethoadon.class, idct);
            Float tru = ctdhx.getSoluong() * ctdhx.getDongiaban();
            sess.delete(ctdhx); 
            Hoadon dh = (Hoadon) sess.get(Hoadon.class, iddh);
            dh.setTrigiahoadon(dh.getTrigiahoadon()-tru);
            sess.getTransaction().commit();
            mv.addAttribute("dh",dh);
            List<Chitiethoadon> chitiethoadons = sess.createQuery("from Chitiethoadon where mahoadon like '%"+iddh+"%'").list();
            mv.addAttribute("ctdhs",chitiethoadons);
            List<Sanpham> sps = sess.createQuery("from Sanpham").list();
            mv.addAttribute("sps", sps);
            return "chitietdonhang";            
        }
    }
    /*End xoactdh.htm*/
    
    /*Start capnhatctdh.htm chưa đạt*/
    @RequestMapping(value = "capnhatctdh.htm", method = RequestMethod.GET)
    public String capnhatCTDH(ModelMap mv, HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            int max = Integer.parseInt(hsr.getParameter("idmax"));
            String iddh= hsr.getParameter("iddh");
            int stt=1;
            float f=0;
            for (int i=0; i<max;i++)
            {
                String idc ="idct"+stt;
                int idct= Integer.parseInt(hsr.getParameter(idc));
                Chitiethoadon ct = (Chitiethoadon) sess.get(Chitiethoadon.class, idct);
                String slc ="slsp"+stt;
                int slct= Integer.parseInt(hsr.getParameter(slc));
                if(ct.getSoluong()!=slct)
                {
                    ct.setSoluong(slct);
                    sess.getTransaction().commit();
                    f=f+ct.getSoluong()*ct.getDongiaban();
                    sess.beginTransaction();
                }
                f=f+ct.getSoluong()*ct.getDongiaban();
                stt++;
            }
            Hoadon dhc = (Hoadon) sess.get(Hoadon.class, iddh);
            dhc.setTrigiahoadon(f);
            sess.getTransaction().commit();
            Hoadon dh = (Hoadon) sess.get(Hoadon.class, iddh);
            mv.addAttribute("dh",dh);
            List<Chitiethoadon> chitiethoadons = sess.createQuery("from Chitiethoadon where mahoadon like '%"+iddh+"%'").list();
            mv.addAttribute("ctdhs",chitiethoadons);
            List<Sanpham> sps = sess.createQuery("from Sanpham").list();
            mv.addAttribute("sps", sps);
            return "chitietdonhang";            
        }
    }
    @RequestMapping(value = "capnhatctdh.htm", method = RequestMethod.POST)    
    public String capnhatCTDH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            int max = Integer.parseInt(hsr.getParameter("idmax"));
            String iddh= hsr.getParameter("iddh");
            int stt=1;
            for (int i=0; i<max;i++)
            {
                String idc ="idct"+stt;
                int idct= Integer.parseInt(hsr.getParameter(idc));
                Chitiethoadon ct = (Chitiethoadon) sess.get(Chitiethoadon.class, idct);
                String slc ="slsp"+stt;
                int slct= Integer.parseInt(hsr.getParameter(slc));
                if(ct.getSoluong()!=slct)
                {
                    ct.setSoluong(slct);
                    sess.getTransaction().commit();
                    sess.beginTransaction();
                }
                stt++;
            }
            Hoadon dh = (Hoadon) sess.get(Hoadon.class, iddh);
            mv.addAttribute("dh",dh);
            List<Chitiethoadon> chitiethoadons = sess.createQuery("from Chitiethoadon where mahoadon like '%"+iddh+"%'").list();
            mv.addAttribute("ctdhs",chitiethoadons);
            List<Sanpham> sps = sess.createQuery("from Sanpham").list();
            mv.addAttribute("sps", sps);
            return "chitietdonhang";            
        }
    }
    /*End capnhatctdh.htm*/
    
    /*Start duyetdh.htm*/
    @RequestMapping(value = "duyetdh.htm", method = RequestMethod.GET)
    public String duyetDH(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                String id= hsr.getParameter("iddh");
                Hoadon dh= (Hoadon) sess.get(Hoadon.class,id);
                dh.setTrangthai(2);
                sess.save(dh);
                sess.getTransaction().commit();
                List<Hoadon> cxls=sess.createQuery("from Hoadon H where H.trangthai=1").list();
                mv.addAttribute("cxls",cxls);
                List<Hoadon> dcgs=sess.createQuery("from Hoadon H where H.trangthai=2 or H.trangthai=3 or H.trangthai=4 ").list();
                mv.addAttribute("dcgs",dcgs);
                List<Hoadon> hts=sess.createQuery("from Hoadon H where H.trangthai=5").list();
                mv.addAttribute("hts",hts);
                List<Hoadon> huys=sess.createQuery("from Hoadon H where H.trangthai=0").list();
                mv.addAttribute("huys",huys);
                return "LoadDH";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "duyetdh.htm", method = RequestMethod.POST)    
    public String duyetDH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                String id= hsr.getParameter("iddh");
                Hoadon dh= (Hoadon) sess.get(Hoadon.class,id);
                dh.setTrangthai(2);
                sess.save(dh);
                sess.getTransaction().commit();
                List<Hoadon> hoadons=sess.createQuery("from Hoadon").list();
                mv.addAttribute("hoadons",hoadons);
                return "LoadDH";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End duyetdh.htm*/ 
    
    /*Start huydh.htm*/
    @RequestMapping(value = "huydh.htm", method = RequestMethod.GET)
    public String huyDH(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                String id= hsr.getParameter("iddh");
                Hoadon dh= (Hoadon) sess.get(Hoadon.class,id);
                dh.setTrangthai(0);
                sess.save(dh);
                sess.getTransaction().commit();
                List<Hoadon> hoadons=sess.createQuery("from Hoadon").list();
                mv.addAttribute("hoadons",hoadons);
                return "LoadDH";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "huydh.htm", method = RequestMethod.POST)    
    public String huyDH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                String id= hsr.getParameter("iddh");
                Hoadon dh= (Hoadon) sess.get(Hoadon.class,id);
                dh.setTrangthai(0);
                sess.save(dh);
                sess.getTransaction().commit();
                List<Hoadon> hoadons=sess.createQuery("from Hoadon").list();
                mv.addAttribute("hoadons",hoadons);
                return "LoadDH";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End huydh.htm*/ 
    
    /*Start loadtonkho.htm*/
    @RequestMapping(value = "loadtonkho.htm", method = RequestMethod.GET)
    public String Loadtonkho(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
            return "LoadTonKho";
        }
    }
    @RequestMapping(value = "loadtonkho.htm", method = RequestMethod.POST)    
    public String Loadtonkho(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
            return "LoadTonKho";
        }
    }
    /* End loadtonkho.htm*/
}
