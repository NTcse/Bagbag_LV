
package controller;


import java.time.Instant;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Admin;
import model.HibernateUtil;
import model.User;
import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
    /*Start home.htm*/
    @RequestMapping(value = "home.htm", method = RequestMethod.GET)
    public String Login(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String id= (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", id);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,id);
                mv.addAttribute("id",kh);
                return "home";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }  
    }
    @RequestMapping(value = "home.htm", method = RequestMethod.POST)    
    public String Login(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String id= (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", id);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,id);
                mv.addAttribute("id",kh);
                return "home";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }  
    }
    /* End home.htm*/
    
    /*Start Loadql.htm*/
    @RequestMapping(value = "loadql.htm", method = RequestMethod.GET)
    public String LoadQL(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                List<Admin> admins=sess.createQuery("from Admin A where A.capdo=1").list();
                mv.addAttribute("admins",admins);
                return "LoadQL";
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }  
    }
    @RequestMapping(value = "loadql.htm", method = RequestMethod.POST)    
    public String LoadQL(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }
            else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                List<Admin> admins=sess.createQuery("from Admin A where A.capdo=1").list();
                mv.addAttribute("admins",admins);
                return "LoadQL";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }  
    }
    /*End Loadql.htm*/    
    
    /*Start loadaddql.htm*/
    @RequestMapping(value = "loadaddql.htm", method = RequestMethod.GET)
    public String LoadaddQL(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                return "LoadFaddql";
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "loadaddql.htm", method = RequestMethod.POST)    
    public String LoadaddQL(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                return "LoadFaddql";
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End Loadaddql.htm*/    
    
    /*Start addql.htm*/
    @RequestMapping(value = "addql.htm", method = RequestMethod.GET)
    public String addQL(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                String id= "1".concat(hsr.getParameter("id")) ;
                String pass=MD5Library.md5(id);
                String hoten= hsr.getParameter("hoten");
                String sdt= hsr.getParameter("sdt");
                String email = hsr.getParameter("email");
                int trangthai=0;
                int capdo=1;
                if(sess.get(Admin.class,id)==null)
                {
                    Admin adn= new Admin();
                    adn.setIdadmin(id);
                    adn.setPass(pass);
                    adn.setHoten(hoten);
                    adn.setSdt(sdt);
                    adn.setEmail(email);
                    adn.setTrangthai(trangthai);
                    adn.setCapdo(capdo);
                    adn.setThoigiantao(Date.from(Instant.now()));
                    sess.save(adn);
                    sess.getTransaction().commit();
                    List<Admin> admins=sess.createQuery("from Admin A where A.capdo=1").list();
                    mv.addAttribute("admins",admins);
                    return "LoadQL";
                }
                else{
                    String out="Mã nhân viên: "+ id +" đã tồn tại vui lòng kiểm tra lại";
                    mv.addAttribute("messenger",out);
                    return "LoadFaddql";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "addql.htm", method = RequestMethod.POST)    
    public String addQL(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                String id= "1".concat(hsr.getParameter("id")) ;
                String pass=MD5Library.md5(id);
                String hoten= hsr.getParameter("hoten");
                String sdt= hsr.getParameter("sdt");
                String email = hsr.getParameter("email");
                int trangthai=0;
                int capdo=1;
                if(sess.get(Admin.class,id)==null)
                {
                    Admin adn= new Admin();
                    adn.setIdadmin(id);
                    adn.setPass(pass);
                    adn.setHoten(hoten);
                    adn.setSdt(sdt);
                    adn.setEmail(email);
                    adn.setTrangthai(trangthai);
                    adn.setCapdo(capdo);
                    adn.setThoigiantao(Date.from(Instant.now()));
                    sess.save(adn);
                    sess.getTransaction().commit();
                    List<Admin> admins=sess.createQuery("from Admin A where A.capdo=1").list();
                    mv.addAttribute("admins",admins);
                    return "LoadQL";
                }
                else{
                    String out="Mã nhân viên: "+ id +" đã tồn tại vui lòng kiểm tra lại";
                    mv.addAttribute("messenger",out);
                    return "LoadFaddql";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End addql.htm*/ 
    
    /*Start Lockql.htm*/
    @RequestMapping(value = "lockql.htm", method = RequestMethod.GET)
    public String LockQL(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                String idk= hsr.getParameter("idql");
                Admin khk=(Admin)sess.get(Admin.class,idk);
                khk.setTrangthai(2);
                sess.save(khk);
                sess.getTransaction().commit();
                Admin khkt=(Admin)sess.get(Admin.class,idk);
                if(khkt.getTrangthai()==2)
                {
                    List<Admin> admins=sess.createQuery("from Admin A where A.capdo=1").list();
                    mv.addAttribute("admins",admins);
                    return "LoadQL";
                }
                else
                {
                    String out="Khóa tài khoản thất bại";
                    mv.addAttribute("mess",out);
                    return "LoadQL";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "lockql.htm", method = RequestMethod.POST)    
    public String LockQL(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                String idk= hsr.getParameter("idql");
                Admin khk=(Admin)sess.get(Admin.class,idk);
                khk.setTrangthai(2);
                sess.save(khk);
                sess.getTransaction().commit();
                Admin khkt=(Admin)sess.get(Admin.class,idk);
                if(khkt.getTrangthai()==2)
                {
                    List<Admin> admins=sess.createQuery("from Admin A where A.capdo=1").list();
                    mv.addAttribute("admins",admins);
                    return "LoadQL";
                }
                else
                {
                    String out="Khóa tài khoản thất bại";
                    mv.addAttribute("mess",out);
                    return "LoadQL";
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End Lockql.htm*/
    
    /*Start Loadkh.htm*/
    @RequestMapping(value = "loadkh.htm", method = RequestMethod.GET)
    public String LoadKH(ModelMap mv, HttpServletRequest hsr)
    {   
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                List<User> users=sess.createQuery("from User ").list();
                mv.addAttribute("users",users);
                return "LoadKH";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "loadkh.htm", method = RequestMethod.POST)    
    public String LoadKH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                List<User> users=sess.createQuery("from User ").list();
                mv.addAttribute("users",users);
                return "LoadKH";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End Loadkh.htm*/
    
     /*Start caplaimkkh.htm*/
    @RequestMapping(value = "caplaimkkh.htm", method = RequestMethod.GET)
    public String CaplaiMK(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else 
            {
            Admin ad=(Admin)sess.get(Admin.class,ss);
            mv.addAttribute("id",ad);
            String idcl= hsr.getParameter("idkh");
            User khcl=(User)sess.get(User.class,idcl);
            khcl.setTrangthai(0);    
                if (ad!=null && khcl.getTrangthai()==2)
                {
                    String out="Không thể cấp lại mật khẩu do tài khoản đã bị khóa";
                    mv.addAttribute("mess",out);
                    return "LoadKH";
                }
                else
                {
                    khcl.setPass(MD5Library.md5(idcl));
                    sess.save(khcl);
                    sess.getTransaction().commit();

                     User khkt=(User)sess.get(User.class,idcl);
                    if(khkt.getTrangthai()==0)
                    {
                        List<User> users=sess.createQuery("from User ").list();
                        mv.addAttribute("users",users);
                        return "LoadKH";
                    }
                    else
                    {
                        String out="Cấp lại mật khẩu cho khách hàng thất bại";
                        mv.addAttribute("mess",out);
                        return "LoadKH";
                    }
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "caplaimkkh.htm", method = RequestMethod.POST)    
    public String CaplaiMK(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else 
            {
            Admin ad=(Admin)sess.get(Admin.class,ss);
            mv.addAttribute("id",ad);
            String idcl= hsr.getParameter("idkh");
            User khcl=(User)sess.get(User.class,idcl);
            khcl.setTrangthai(0);    
                if (ad!=null && khcl.getTrangthai()==2)
                {
                    String out="Không thể cấp lại mật khẩu do tài khoản đã bị khóa";
                    mv.addAttribute("mess",out);
                    return "LoadKH";
                }
                else
                {
                    khcl.setPass(idcl);
                    sess.save(khcl);
                    sess.getTransaction().commit();

                     User khkt=(User)sess.get(User.class,idcl);
                    if(khkt.getTrangthai()==0)
                    {
                        List<User> users=sess.createQuery("from User ").list();
                        mv.addAttribute("users",users);
                        return "LoadKH";
                    }
                    else
                    {
                        String out="Cấp lại mật khẩu cho khách hàng thất bại";
                        mv.addAttribute("mess",out);
                        return "LoadKH";
                    }
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End caplaimkkh.htm*/
    
    /*Start loadchangekh.htm*/
    @RequestMapping(value = "loadchangekh.htm", method = RequestMethod.GET)
    public String LoaddieuchinhKH(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                String iddc= hsr.getParameter("idkh");
                User khdc=(User)sess.get(User.class,iddc);
                mv.addAttribute("users",khdc);
                return "FdieuchinhKH";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "loadchangekh.htm", method = RequestMethod.POST)    
    public String LoaddieuchinhKH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin kh=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",kh);
                String iddc= hsr.getParameter("idkh");
                User khdc=(User)sess.get(User.class,iddc);
                mv.addAttribute("users",khdc);
                return "FdieuchinhKH";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End loadchangekh.htm*/
    
    /*Start changekh.htm*/
    @RequestMapping(value = "changekh.htm", method = RequestMethod.GET)
    public String DieuchinhKH(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin ad=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",ad);
                String iddc= hsr.getParameter("idkh");
                User khcl=(User)sess.get(User.class,iddc);
                if (ad!=null && khcl.getTrangthai()==2)
                {
                    String out="Không thể điều chỉnh cấp độ do tài khoản đã bị khóa";
                        mv.addAttribute("mess",out);
                        return "FdieuchinhKH";
                }
                else
                {
                    String s= hsr.getParameter("capdo");
                    int capdo = Integer.parseInt(s);
                    khcl.setCapdo(capdo);
                    sess.save(khcl);
                    sess.getTransaction().commit();
                     User khkt=(User)sess.get(User.class,iddc);
                    if(khkt.getCapdo()==capdo )
                    {
                        List<User> users=sess.createQuery("from User ").list();
                        mv.addAttribute("users",users);
                        return "LoadKH";
                    }
                    else
                    {
                        String out="Điều chỉnh khách hàng thất bại";
                        mv.addAttribute("mess",out);
                        User khdcl=(User)sess.get(User.class,iddc);
                        mv.addAttribute("users",khdcl);
                        return "FdieuchinhKH";
                    }
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "changekh.htm", method = RequestMethod.POST)    
    public String DieuchinhKH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        try{
            if(ss==null)
            {
                String out="Bạn không thể thực hiện hành động này. Vui lòng kiểm tra lại";
                mv.addAttribute("messenger", out);
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                Admin ad=(Admin)sess.get(Admin.class,ss);
                mv.addAttribute("id",ad);
                String iddc= hsr.getParameter("idkh");
                User khcl=(User)sess.get(User.class,iddc);
                if (ad!=null && khcl.getTrangthai()==2)
                {
                    String out="Không thể điều chỉnh cấp độ do tài khoản đã bị khóa";
                        mv.addAttribute("mess",out);
                        return "FdieuchinhKH";
                }
                else
                {
                    String s= hsr.getParameter("capdo");
                    int capdo = Integer.parseInt(s);
                    khcl.setCapdo(capdo);
                    sess.save(khcl);
                    sess.getTransaction().commit();
                     User khkt=(User)sess.get(User.class,iddc);
                    if(khkt.getCapdo()==capdo )
                    {
                        List<User> users=sess.createQuery("from User ").list();
                        mv.addAttribute("users",users);
                        return "LoadKH";
                    }
                    else
                    {
                        String out="Điều chỉnh khách hàng thất bại";
                        mv.addAttribute("mess",out);
                        User khdcl=(User)sess.get(User.class,iddc);
                        mv.addAttribute("users",khdcl);
                        return "FdieuchinhKH";
                    }
                }
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End changekh.htm*/
}