
package controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Admin;
import model.Chitiethoadon;
import model.HibernateUtil;
import model.Hoadon;
import model.Sanpham;
import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
    /*Start home.htm*/
    @RequestMapping(value = "home.htm", method = RequestMethod.GET)
    public String Login(ModelMap mv,HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
            return "home";
        }
    }
    @RequestMapping(value = "home.htm", method = RequestMethod.POST)    
    public String Login(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
            return "home";
        }
    }
    /* End home.htm*/
       /*Start loaddh.htm*/
    @RequestMapping(value = "loaddh.htm", method = RequestMethod.GET)
    public String LoadDH(ModelMap mv, HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Hoadon> dtns=sess.createQuery("from Hoadon H where H.trangthai=2").list();
            mv.addAttribute("dtns",dtns);
            List<Hoadon> ddgs=sess.createQuery("from Hoadon H where H.trangthai=3").list();
            mv.addAttribute("ddgs",ddgs);
            List<Hoadon> dvcs=sess.createQuery("from Hoadon H where H.trangthai=4").list();
            mv.addAttribute("dvcs",dvcs);
            List<Hoadon> hts=sess.createQuery("from Hoadon H where H.trangthai=5").list();
            mv.addAttribute("hts",hts);
            List<Hoadon> huys=sess.createQuery("from Hoadon H where H.trangthai=0").list();
            mv.addAttribute("huys",huys);
            return "LoadDH";
        }
    }
    @RequestMapping(value = "loaddh.htm", method = RequestMethod.POST)    
    public String LoadDH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            List<Hoadon> hoadons=sess.createQuery("from Hoadon").list();
            mv.addAttribute("hoadons",hoadons);
            return "LoadDH";
        }
    }
    /*End loaddh.htm*/
    
    /*Start loadctdh.htm*/
    @RequestMapping(value = "loadctdh.htm", method = RequestMethod.GET)
    public String LoadCTDH(ModelMap mv, HttpServletRequest hsr)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        String iddh= hsr.getParameter("iddh");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
            Hoadon dh = (Hoadon) sess.get(Hoadon.class, iddh);
            mv.addAttribute("dh",dh);
            List<Chitiethoadon> chitiethoadons = sess.createQuery("from Chitiethoadon where mahoadon like '%"+iddh+"%'").list();
            mv.addAttribute("ctdhs",chitiethoadons);
            List<Sanpham> sps = sess.createQuery("from Sanpham").list();
            mv.addAttribute("sps", sps);
            return "chitietdonhang";
        }
    }
    @RequestMapping(value = "loadctdh.htm", method = RequestMethod.POST)    
    public String LoadCTDH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        String iddh= hsr.getParameter("iddh");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        if(kh==null)
        {
            sess.getTransaction().commit();
            sess.close();
            return "index";
        }else
        {
           Hoadon dh = (Hoadon) sess.get(Hoadon.class, iddh);
            mv.addAttribute("dh",dh);            
            return "chitietdonhang";
        }
    }
    /*End loadctdh.htm*/
    
     /*Start duyetdh.htm*/
    @RequestMapping(value = "duyetdh.htm", method = RequestMethod.GET)
    public String duyetDH(ModelMap mv,HttpServletRequest hsr )
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                String id= hsr.getParameter("iddh");
                Hoadon dh= (Hoadon) sess.get(Hoadon.class,id);
                int tt= Integer.parseInt(hsr.getParameter("tt"));
                dh.setTrangthai(tt);
                sess.save(dh);
                sess.getTransaction().commit();
                List<Hoadon> dtns=sess.createQuery("from Hoadon H where H.trangthai=2").list();
                mv.addAttribute("dtns",dtns);
                List<Hoadon> ddgs=sess.createQuery("from Hoadon H where H.trangthai=3").list();
                mv.addAttribute("ddgs",ddgs);
                List<Hoadon> dvcs=sess.createQuery("from Hoadon H where H.trangthai=4").list();
                mv.addAttribute("dvcs",dvcs);
                List<Hoadon> hts=sess.createQuery("from Hoadon H where H.trangthai=5").list();
                mv.addAttribute("hts",hts);
                List<Hoadon> huys=sess.createQuery("from Hoadon H where H.trangthai=0").list();
            mv.addAttribute("huys",huys);
                return "LoadDH";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    @RequestMapping(value = "duyetdh.htm", method = RequestMethod.POST)    
    public String duyetDH(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
        HttpSession session = hsr.getSession();
        String ss = (String) session.getAttribute("sessadmin");
        session.setAttribute("sessadmin", ss);
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Admin kh=(Admin)sess.get(Admin.class,ss);
        mv.addAttribute("id",kh);
        try{
            if(session.getAttribute("sessadmin")==null)
            {
                sess.getTransaction().commit();
                sess.close();
                return "index";
            }else
            {
                String id= hsr.getParameter("iddh");
                Hoadon dh= (Hoadon) sess.get(Hoadon.class,id);
                dh.setTrangthai(2);
                sess.save(dh);
                sess.getTransaction().commit();
                List<Hoadon> hoadons=sess.createQuery("from Hoadon").list();
                mv.addAttribute("hoadons",hoadons);
                return "LoadDH";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            return "Error";
        }
    }
    /*End duyetdh.htm*/ 
    
    /*---------*/
    
    @RequestMapping(value = "loadxk.htm", method = RequestMethod.GET)
    public String LoadDM (ModelMap mv, HttpServletRequest hsr)
    {        
        HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
        return "LoadXK";
        }
    }
    @RequestMapping(value = "loadxk.htm", method = RequestMethod.POST)    
    public String LoadDM(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
       HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
        return "LoadXK";
        }
    }
    
    @RequestMapping(value = "loadnk.htm", method = RequestMethod.GET)
    public String LoadNCC(ModelMap mv, HttpServletRequest hsr)
    {        
       HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
        return "LoadNK";
        }
    }
    @RequestMapping(value = "loadnk.htm", method = RequestMethod.POST)    
    public String LoadNCC(ModelMap mv, HttpServletRequest hsr, HttpServletResponse response)
    {
       HttpSession session = hsr.getSession();
        if(session.getAttribute("sessadmin")==null)
        {
            return "index";
        }else
        {
            String id= (String) session.getAttribute("sessadmin");
            Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Admin kh=(Admin)sess.get(Admin.class,id);
                 mv.addAttribute("id",kh);
            return "LoadNK";
        }
    }
    
}
